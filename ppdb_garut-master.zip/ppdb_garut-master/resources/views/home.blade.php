@extends('layouts.home')

@section('content')
<div id="page-wrapper">
    <div id="page-inner">

        <div class="row">
            <div class="col-md-12">
               
                                  
                <h2 class="col-md-12">Berkas Pendaftaran dibawa</h2>
                                        <h2 class="col-md-12">saat mengikuti test seleksi :</h2>
                                        <p class="col-md-12">
                                        <h3>1.Fotokopi Raport SMP kelas 7-9 Semester 1</h3>
                                        <h3>2.Fotokopi Akte kelahiran</h3>
                                        <h3>3.Fotokopi Kartu Keluarga</h3>
                                        <h3>4.Pas Photo Berwarna(Berkemeja)Ukuran :3 X 4(6 lembar)</h3>
                                        </p>




    </div>
</div>
</div>
</div>
<!-- /. ROW  -->
@endsection
